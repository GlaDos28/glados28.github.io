'use strict';

var replaced = require('replaced');

exports.log = function() {
  console.log('Testing from replacedsub: '+replaced.greetstr);
}
